module.exports={
  "developerMode": false,
  "database":{
      host: '49.234.114.90',
      user: 'root',
      password: 'MiHu581514!',
      database: 'loghome',
  },
  "uniCloudUrl": "https://fc-mp-e1064b8d-45cc-43f3-b55b-61ad80dbee0c.next.bspapp.com/uniId",
  "emailApiKey": "hbxnSNlJxWc2EMt4jwVuUB019Iln3Sj8"
}