# LogHome TTS server assets

This directory is ready to publish as a static `/tts/` directory. The Android
app keeps the sherpa-onnx native runtime inside the APK and downloads only the
versioned voice model from this directory.

## Files to upload

- `vits-piper-zh_CN-chaowen-medium-int8.tar.bz2`
- `vits-piper-zh_CN-chaowen-medium-int8.tar.bz2.sha256`
- `manifest.json`
- `MODEL-NOTICE.md`

Keep the archive byte-for-byte unchanged. The Android client pins both its
length and SHA-256 digest.

## Example deployment

```bash
rsync -av --delete ./tts-server-assets/ user@example.com:/var/www/downloads/tts/
```

Example nginx location:

```nginx
location /tts/ {
    alias /var/www/downloads/tts/;
    autoindex off;
    add_header Cache-Control "public, max-age=31536000, immutable";
    types {
        application/json json;
        application/x-bzip2 bz2;
    }
}
```

Nginx static-file serving supports byte ranges by default. Do not disable
`Range`/`Accept-Ranges`, because the app resumes interrupted downloads.

Verify the deployed file:

```bash
curl -L https://downloads.example.com/tts/vits-piper-zh_CN-chaowen-medium-int8.tar.bz2 \
  | shasum -a 256
```

Build the app against the uploaded directory:

```bash
./gradlew assembleRelease \
  -PloghomeTtsModelBaseUrl=https://downloads.example.com/tts/
```

The equivalent environment variable is `LOGHOME_TTS_MODEL_BASE_URL`.
