export const state = () => ({
  // 状态定义
})

export const mutations = {
  // 突变定义
}

export const actions = {
  // 动作定义
}

export const getters = {
  // 获取器定义
} 