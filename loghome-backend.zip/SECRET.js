module.exports = {
	SECRET: 'loghome20211119', //jwt密钥
	TencentSecretId: 'AKIDJcopfLtEQTNyPgoncKtRr6DAveCZltqe',
	TencentSecretKey: 'LURDpGZgkeP0SjqmYJvQqATcaUSYXQWu'
};
