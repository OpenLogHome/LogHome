module.exports={
    "developerMode": false,
    "database":{
        host: 'sql.ricepastem.cafe',
        port: 20345,
        user: 'loghome',
        password: 'loghome250720!',
        database: 'loghome',
    },
    "uniCloudUrl": "https://env-00jxtj815hua.dev-hz.cloudbasefunction.cn/http/router",
    "emailApiKey": "hbxnSNlJxWc2EMt4jwVuUB019Iln3Sj8"
}