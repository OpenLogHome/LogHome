// 引入banner管理路由
let bannersRouter = require('./banners');
router.use('/banners', bannersRouter); 